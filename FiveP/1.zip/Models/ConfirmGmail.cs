﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace FiveP.Models
{
    public class ConfirmGmail
    {
        public String strEmailReceived { get; set; }
        public String strTitle { get; set; }
        public String strContent { get; set; }
        public String pass { get; set; }
    }
}